/************************
APPLICATION CONFIGURATION
************************/
globalThis.__beyond_config = {"distribution":{"local":false,"key":"2379090699","environment":"development","mode":"amd","baseDir":"/"},"application":{"package":"@beyond/docs","version":1,"languages":{"default":"en","supported":["en"]},"connect":true,"host":"undefined/beyond/docs","params":{"logs":"./logs","test2":"test2"}},"libraries":[{"package":"@beyond/ui","version":1,"connect":false}]};
